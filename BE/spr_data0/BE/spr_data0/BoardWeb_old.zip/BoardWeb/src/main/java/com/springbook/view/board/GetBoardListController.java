package com.springbook.view.board;

import com.springbook.view.controller.Controller;

public class GetBoardListController implements Controller{
	
}
